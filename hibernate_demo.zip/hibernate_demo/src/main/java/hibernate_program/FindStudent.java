package hibernate_program;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FindStudent {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=factory.createEntityManager();
		Student s=manager.find(Student.class,1);
		if(s!=null) {
			System.out.println(" Student Id: "+s.getId()+"\n Student name: "+s.getName()+"\n Student Age: "+s.getAge()+"\n Student Address: "+s.getAddress());
		}
		else {
			System.out.println("ID not found");
		}
	}

}
