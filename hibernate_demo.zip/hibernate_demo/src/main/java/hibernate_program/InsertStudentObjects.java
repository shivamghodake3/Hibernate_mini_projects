package hibernate_program;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InsertStudentObjects {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		
		Student s = new Student();
		s.setId(3);
		s.setName("sara");
		s.setAge(22);
		s.setAddress("goa");
		
		transaction.begin();
		manager.persist(s);
		transaction.commit();
	}

}
