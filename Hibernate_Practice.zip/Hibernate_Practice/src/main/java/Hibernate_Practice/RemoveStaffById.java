package Hibernate_Practice;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class RemoveStaffById {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter staff id to remove details: ");
		int id=sc.nextInt();
		
		HospitalStaff s=manager.find(HospitalStaff.class,id);
		
		if(s!=null) {
			transaction.begin();
			manager.remove(s);
			transaction.commit();
		}
		else {
			System.out.println("ID NOT FOUND.");
		}
		
		System.out.println("Id "+id+" deleted successfully..!");
	}

}
