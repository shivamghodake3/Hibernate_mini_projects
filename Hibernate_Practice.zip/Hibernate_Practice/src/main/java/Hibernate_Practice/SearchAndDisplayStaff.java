package Hibernate_Practice;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SearchAndDisplayStaff {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=factory.createEntityManager();
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the staff id to display all details: ");
		int id=sc.nextInt();
		
		HospitalStaff s=manager.find(HospitalStaff.class,id);
		if(s!=null) {
			System.out.println(" Staff Id: "+s.getId()+"\n Staff name: "+s.getName()+"\n Staff designation: "+s.getDesignation()+"\n Staff salary: "+s.getSal());
		}
		else {
			System.out.println("ID not found");
		}
	}

}
