package Hibernate_Practice;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InsertStaff {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction  transaction=manager.getTransaction();
		
		Scanner sc=new Scanner(System.in);
//		for(int i=1;i<=3;i++) {
		System.out.println("enter the staff details: ");
		System.out.println("enter staff id: ");
		int id=sc.nextInt();
		System.out.println("enter name of staff");
		String name=sc.next();
		System.out.println("enter designation of staff");
		String designation=sc.next();
		System.out.println("enter salary of staff");
		double sal=sc.nextDouble();
		
		HospitalStaff s=new HospitalStaff();
		s.setId(id);
		s.setName(name);
		s.setDesignation(designation);
		s.setSal(sal);
		
		transaction.begin();
		manager.persist(s);
		transaction.commit();
//		}
		System.out.println("Records of Staff added Successfully..!");
	}

}
