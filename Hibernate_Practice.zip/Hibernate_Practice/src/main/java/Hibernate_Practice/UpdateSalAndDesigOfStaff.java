package Hibernate_Practice;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class UpdateSalAndDesigOfStaff {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter staff id to update details: ");
		int id=sc.nextInt();
		System.out.println("enter staff designation to update");
		String designation=sc.next();
		System.out.println("enter staff sal to update");
		double sal=sc.nextDouble();
		
		HospitalStaff s=manager.find(HospitalStaff.class,id);
		
		if(s!=null) {
			s.setDesignation(designation);
			s.setSal(sal);
			transaction.begin();
			manager.merge(s);
			transaction.commit();
			transaction.begin();
			manager.merge(s);
			transaction.commit();
		}
		else {
			System.out.println("ID NOT FOUND.");
		}
		
		System.out.println("designation and salaray updated successfully..!");
	}

}
