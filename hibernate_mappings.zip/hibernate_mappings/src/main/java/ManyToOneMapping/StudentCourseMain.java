package ManyToOneMapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class StudentCourseMain {
	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		
		//creating multiple courses
		Course c1=new Course();
		c1.setCourseid(111);
		c1.setCname("java");
		c1.setDuration(2);
		c1.setFees(25000);
		
		Course c2=new Course();
		c2.setCourseid(222);
		c2.setCname("web technology");
		c2.setDuration(1);
		c2.setFees(15000);
		
		Course c3=new Course();
		c3.setCourseid(333);
		c3.setCname("sql");
		c3.setDuration(1);
		c3.setFees(10000);
		
		//creating student
		Student s=new Student();
		s.setStudentid(1);
		s.setName("sarah");
		s.setStream("computer science");
		
		//set student to all courses
		c1.setStudent(s);
		c2.setStudent(s);
		c3.setStudent(s);
		
		//storing objects into db
		transaction.begin();
		manager.persist(s);
		manager.persist(c1);
		manager.persist(c2);
		manager.persist(c3);
		transaction.commit();
	}
}
