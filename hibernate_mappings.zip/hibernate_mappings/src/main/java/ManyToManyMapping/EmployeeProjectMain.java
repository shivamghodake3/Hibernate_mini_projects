package ManyToManyMapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class EmployeeProjectMain {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction =manager.getTransaction();
		
		//creating multiple employee
		Employee e1=new Employee();
		e1.setEid(1);
		e1.setName("suresh");
		e1.setDesignation("java developer");
		
		Employee e2=new Employee();
		e2.setEid(2);
		e2.setName("asha");
		e2.setDesignation("front end developer");
		
		//creating multiple projects
		Projects p1=new Projects();
		p1.setProjectid(101);
		p1.setName("banking applicaton");
		p1.setDuration(8);
		
		Projects p2=new Projects();
		p2.setProjectid(104);
		p2.setName("shopping app");
		p2.setDuration(5);
		
		Projects p3=new Projects();
		p3.setProjectid(105);
		p3.setName("candy crush game app");
		p3.setDuration(12);
		
		//creating list of projects
		List<Projects> projectList=new ArrayList<Projects>();
		projectList.add(p1);
		projectList.add(p2);
		projectList.add(p3);
		
		//setting project list to multiple employee
		e1.setProjects(projectList);
		e2.setProjects(projectList);
		
		//store all objects into db
		transaction.begin();
		manager.persist(e1);
		manager.persist(e2);
		manager.persist(p1);
		manager.persist(p2);
		manager.persist(p3);
		transaction.commit(); 
	}

}
