package ManyToManyMapping;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Projects {

	@Id
	private int projectid;
	private String name;
	private int duration;
	
	
	public int getProjectid() {
		return projectid;
	}
	public void setProjectid(int projectid) {
		this.projectid = projectid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	
}
