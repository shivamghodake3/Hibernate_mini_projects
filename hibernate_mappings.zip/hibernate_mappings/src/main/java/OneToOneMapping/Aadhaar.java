package OneToOneMapping;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Aadhaar {

	@Id
	private int aid;
	private long aadhaarno;
	
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public long getAadhaarno() {
		return aadhaarno;
	}
	public void setAadhaarno(long aadhaarno) {
		this.aadhaarno = aadhaarno;
	}
	
	
}
