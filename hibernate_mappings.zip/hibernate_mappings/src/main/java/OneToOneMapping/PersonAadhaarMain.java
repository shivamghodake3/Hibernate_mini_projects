package OneToOneMapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class PersonAadhaarMain {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		
		//creating aadhaar object
		Aadhaar a1=new Aadhaar();
		a1.setAid(1);
		a1.setAadhaarno(667016309878l);
		
		//creating person object
		Person p1=new Person();
		p1.setPid(1);
		p1.setName("darshan");
		p1.setOccupation("driver");
		
		//set aadhaar object to person object
		p1.setAadhaar(a1);
		
		//insert all objects to db
		transaction.begin();
		manager.persist(a1);
		manager.persist(p1);
		transaction.commit();
	}

}
